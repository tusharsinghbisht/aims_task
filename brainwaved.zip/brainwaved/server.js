const express = require("express");
const path = require("path");


const app = express();

app.use(express.json());  
app.use(express.urlencoded({ extended: true }));  
app.use(express.static(path.join(__dirname, "public")));  
app.set("view engine", "ejs");  
app.set("views", path.join(__dirname, "views"));  


app.get('/s3cr37_p14c3_f0r_4m4zin9_p33p5', (req, res) => {
    const { fee } = req.query;

    if (!fee) {
        return res.send("I need 500$ ?fee to let you enter the secret place");
    }
    if (fee !== "500") {
        return res.send("Only 500$ please")
    }

    res.cookie('secret_cookie', 'Base64 bWVfZWtfZ2FsdF9wYXNzd29yZF9odQo=', {
        maxAge: 900000*4, // Cookie will expire in 15 minutes
        httpOnly: true, 
        sameSite: 'strict' 
      });
    
    res.set("XXX-Hidden-Password", "enJfcnhfbnl2cmFfdWhfeXpuYl9xcnEK")
    res.set("XXX-Hidden-Password-Encoding", "rot13;base64")
    return res.render('secret_page');

});

app.get('/v3ry_v3ry_s3cr3t_l09in_p493_43289230232', (req, res) => {
    res.render("very_secret_page");
});


app.post('/v3ry_v3ry_s3cr3t_l09in_p493_43289230232', (req, res) => {
    const { user, pass } = req.body;
    
    if (!user || !pass) {
        return res.status(500).send("Not a valid request")
    }
    
    if (user == "usr_benzo" && pass == "me_ek_alien_hu_lmao_ded") {
        return res.status(200).send("Wahh! sherr, here's your flag: brAInwave{h4mtum_1k_k@mr3_m3_b4nd}")
    }
    
    return res.status(200).send("Nice try! but i can't give you the flag")
});


const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
